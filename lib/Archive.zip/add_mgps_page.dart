import 'package:flutter/material.dart';

class AddMGPSPage extends StatelessWidget {
  const AddMGPSPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Add MGPS')),
      body: const Center(child: Text('AddMGPSPage Placeholder')),
    );
  }
}
