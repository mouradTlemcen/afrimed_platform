import 'package:firebase_core/firebase_core.dart';

class DefaultFirebaseOptions {
  static FirebaseOptions get currentPlatform {
    return const FirebaseOptions(
      apiKey: "AIzaSyA51e4IyIhDP4gwU7HxbeegrlD5nLSSCps",
      authDomain: "benosafrimed.firebaseapp.com",
      projectId: "benosafrimed",
      storageBucket: "benosafrimed.firebasestorage.app",
      messagingSenderId: "78700857321",
      appId: "1:78700857321:web:7677c5abfa1575bd926d78",
      measurementId: "G-196J8STWLF",
    );
  }
}
